module IsolatedVolumeTests_FSI_Iter17_3d
using Test
using GridapTopOpt
using Gridap
using GridapGmsh

using GridapEmbedded
using GridapEmbedded.LevelSetCutters
using GridapEmbedded.Distributed
using Gridap.Geometry, Gridap.FESpaces, Gridap.CellData, Gridap.Adaptivity, Gridap.Arrays

using GridapDistributed, PartitionedArrays

function main_gmsh(ranks;vtk=false)
  path = "./results/IsolatedGmsh_3d_fsi/"
  i_am_main(ranks) && mkpath(path)

  model = GmshDiscreteModel(ranks,(@__DIR__)*"mesh_3d.msh")

  # Cut the background model
  reffe_scalar = ReferenceFE(lagrangian,Float64,1)
  V_φ = TestFESpace(model,reffe_scalar)
  φh = interpolate(1,V_φ)
  GridapTopOpt.pload!((@__DIR__)*"/LSF_17",get_free_dof_values(φh))

  # Setup integration meshes and measures
  geo = DiscreteGeometry(φh,model)
  cutgeo = cut(model,geo)

  Ωs = DifferentiableTriangulation(Triangulation(cutgeo,PHYSICAL),V_φ)
  Ωf = DifferentiableTriangulation(Triangulation(cutgeo,PHYSICAL_OUT),V_φ)

  cell_values = map(get_cell_dof_values,local_views(φh))

  ψ_s,_ = GridapTopOpt.get_isolated_volumes_mask_polytopal(model,cell_values,["Gamma_s_D"])
  _,ψ_f = GridapTopOpt.get_isolated_volumes_mask_polytopal(model,cell_values,["Gamma_f_D"])

  if vtk
    Ωs_active = Triangulation(cutgeo,ACTIVE)
    Ωf_active = Triangulation(cutgeo,ACTIVE_OUT)

    writevtk(get_triangulation(φh),path*"initial_islands",cellfields=["φh"=>φh,"ψ_f"=>ψ_f,"ψ_s"=>ψ_s];append=false)
    writevtk(Ωs,path*"Omega_s_initial";append=false)
    writevtk(Ωf,path*"Omega_f_initial";append=false)
    writevtk(
      get_triangulation(φh),path*"Isolated_vol_data",
      cellfields=[
        "φh"=>φh,
        "ψ_f"=>ψ_f,
        "ψ_s"=>ψ_s
      ],
      append=false
    );
    writevtk(
      Ωf_active,path*"Isolated_vol_data_active_f",
      cellfields=[
        "φh"=>φh,
        "ψ_f"=>ψ_f,
        "ψ_s"=>ψ_s
      ],
      append=false
    );
    writevtk(
      Ωs_active,path*"Isolated_vol_data_active_s",
      cellfields=[
        "φh"=>φh,
        "ψ_f"=>ψ_f,
        "ψ_s"=>ψ_s
      ],
      append=false
    );
  end
end

with_debug() do distribute
  ranks = distribute(LinearIndices((96,)))
  main_gmsh(ranks;vtk=true)
end

end
